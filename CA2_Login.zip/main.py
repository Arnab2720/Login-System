from flask import Flask,request,redirect,render_template,session, url_for,flash
import pymysql
import os

app = Flask(__name__)
app.secret_key=os.urandom(24)
with open(r".\cred.txt",'r') as credentials:
    cred = credentials.read().strip().split('\n')
    credentials.close()
cred = dict([x.split("=") for x in cred])

host_=cred.get('HOST')
user_=cred.get('USER')
password_=cred.get('PASSWORD')
database_=cred.get('DATABASE')

def create_db_connection():
    connection = pymysql.connect(
        host=host_,
        user=user_,
        password=password_,
        # database=database_,
        cursorclass=pymysql.cursors.DictCursor
    )
    return connection

with open(r".\queries.sql", 'r') as q:
    queries = q.read().strip().split("hi")
    q.close()

query_dict = {
    'create_db_query':queries[0],
    'create_table_query':queries[1],
    'insert_query':queries[2]
}

# Create Database
connection = create_db_connection()
try:
    with connection:
        try:
            with connection.cursor() as cursor:
                cursor.execute(query_dict['create_db_query'])
            connection.commit()
        except pymysql.Error as e:
            print(e)
        try:
            with connection.cursor() as cursor:
                cursor.execute(query_dict['create_table_query'])
            connection.commit()
        except pymysql.Error as e:
            print(e)
        connection.close()
except pymysql.err.Error as e:
    print(e)

@app.route('/')
def login():
    if 'user_id' not in session:
        return render_template("login.html")
    else:
        return redirect(url_for("home"))

@app.route('/home')
def home():
    if 'user_id' in session:
        user_=session['username']
        return render_template("home.html" ,user=user_)
    else:
        return redirect(url_for("login"))

@app.route('/logout')
def logout():
    session.pop("user_id")
    session.pop("username")
    return render_template("logout.html")

@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/login_validation', methods=["POST","GET"])
def login_validation():
    if request.method=="POST":
        username = request.form.get("username")
        password = request.form.get("password")
        query = "SELECT * FROM ca2.users WHERE email='{0}' AND password='{1}';".format(username, password)
        connection=create_db_connection()
        cursor=connection.cursor()
        cursor.execute(query)
        val = cursor.fetchall()
        connection.close()
        if len(val)==1:
            session['user_id']=val[0]['user_id']
            name_ = val[0]['first_name']
            session['username']=name_
            return redirect(url_for("home"))
        else:
            flash("Entered Credential is incorrect!","warning")
            return redirect(url_for("login"))

@app.route('/add_user', methods=["POST","GET"])
def add_user():
    if request.method=="POST":
        fname=request.form.get("fname")
        lname=request.form.get("lname")
        email=request.form.get("email")
        password=request.form.get("password")
        query = f"SELECT * FROM ca2.users WHERE email='{email}';"
        connection=create_db_connection()
        cursor=connection.cursor()
        cursor.execute(query)
        val = cursor.fetchall()
        connection.close()
        if len(val)==0:
            query = query_dict["insert_query"]
            print(query)
            connection=create_db_connection()
            cursor=connection.cursor()
            cursor.execute(query,(fname,lname,email,password))
            connection.commit()
            connection.close()
            return redirect(url_for("login"))
        else:
            flash(f"User with {val[0]['email']} already exist!","warning")
            return redirect(url_for("register"))
            


if __name__=='__main__':
    app.run(debug=True)