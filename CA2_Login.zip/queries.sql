CREATE DATABASE IF NOT EXISTS `ca2`;
hi
CREATE TABLE IF NOT EXISTS `ca2`.`users` (
    `user_id` int(10) NOT NULL AUTO_INCREMENT,
    `first_name` varchar(100) COLLATE utf8_bin NOT NULL,
    `last_name` varchar(100) COLLATE utf8_bin NOT NULL,
    `email` varchar(200) COLLATE utf8_bin NOT NULL,
    `password` varchar(200) COLLATE utf8_bin NOT NULL,
    PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
AUTO_INCREMENT=1 ;
hi
INSERT INTO `ca2`.`users` (`first_name`,`last_name`,`email`,`password`) VALUES (%s, %s,%s, %s);